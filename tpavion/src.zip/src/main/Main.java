package main;


import systeme.SystemeGestion;

public class Main {
    public static void main(String[] args) {
        new SystemeGestion();
    }
}
