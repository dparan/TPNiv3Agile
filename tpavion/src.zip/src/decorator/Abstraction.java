package decorator;

public interface Abstraction {
	/* oblige les classes filles à implémnenter cette méthode */
    public void affichage();
}
